@echo off
title Khoi dong Dich vu Ky so - NSG Sign Bridge
chcp 65001 > nul
cd /d "%~dp0"

echo ========================================================
echo   HE THONG VAN PHONG SO - TRUONG CAO DANG BK NAM SAI GON
echo   Dich vu ket noi chu ky so USB Token & VGCASignTool
echo ========================================================
echo.
echo Dang khoi dong dich vu tai http://localhost:8989 ...
echo Ban co the thu nho cua so nay xuong (khong tat di) de he thong ky hoat dong.
echo.

if exist "%~dp0node.exe" (
    "%~dp0node.exe" "%~dp0server.js"
) else (
    node "%~dp0server.js"
)

pause
