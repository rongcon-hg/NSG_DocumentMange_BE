@echo off
title Cai dat Tu dong khoi dong - NSG Sign Bridge
chcp 65001 > nul
set "CURRENT_DIR=%~dp0"
set "STARTUP_DIR=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"

echo ============================================================
echo   HE THONG VAN PHONG SO - TRUONG CAO DANG BK NAM SAI GON
echo   Cai dat tu dong khoi dong cung Windows cho USB Token Bridge
echo ============================================================
echo.

(
echo Set WshShell = CreateObject^("WScript.Shell"^)
echo WshShell.CurrentDirectory = "%CURRENT_DIR%"
echo WshShell.Run "node server.js", 0, False
) > "%STARTUP_DIR%\NSG_VGCA_SignBridge.vbs"

echo [OK] Da them file tu dong khoi dong vao thu muc Startup:
echo      "%STARTUP_DIR%\NSG_VGCA_SignBridge.vbs"
echo.
echo Tu bay gio, moi khi bat may tinh dich vu se tu dong chay ngam!
echo.
pause
