@echo off
title Cai dat Tu dong khoi dong - NSG Sign Bridge
chcp 65001 > nul
set "CURRENT_DIR=%~dp0"
if "%CURRENT_DIR:~-1%"=="\" set "CURRENT_DIR=%CURRENT_DIR:~0,-1%"
set "STARTUP_DIR=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"

echo ============================================================
echo   HE THONG VAN PHONG SO - TRUONG CAO DANG BK NAM SAI GON
echo   Cai dat tu dong khoi dong cung Windows cho USB Token Bridge
echo ============================================================
echo.

:: Xoa file startup cu neu co
del /f /q "%STARTUP_DIR%\NSG_VGCA_SignBridge.vbs" 2>nul

(
echo Set WshShell = CreateObject^("WScript.Shell"^)
echo Set fso = CreateObject^("Scripting.FileSystemObject"^)
echo currentDir = "%CURRENT_DIR%"
echo WshShell.CurrentDirectory = currentDir
echo nodeExe = currentDir ^& "\node.exe"
echo scriptPath = currentDir ^& "\server.js"
echo If fso.FileExists^(nodeExe^) Then
echo     WshShell.Run """" ^& nodeExe ^& """ """ ^& scriptPath ^& """", 0, False
echo Else
echo     WshShell.Run "node """ ^& scriptPath ^& """", 0, False
echo End If
) > "%STARTUP_DIR%\NSG_VGCA_SignBridge.vbs"

echo [OK] Da cai dat thanh cong vao Startup:
echo      "%STARTUP_DIR%\NSG_VGCA_SignBridge.vbs"
echo.
echo Dang khoi chay dich vu ngam ngay bay gio...
wscript.exe "%STARTUP_DIR%\NSG_VGCA_SignBridge.vbs"

echo.
echo ============================================================
echo   HOAN TAT! Dich vu da duoc bat va se tu chay cung Windows.
echo ============================================================
echo.
pause
