const express = require('express');
const cors = require('cors');
const multer = require('multer');
const { spawn, execSync } = require('child_process');
const path = require('path');
const fs = require('fs');
const os = require('os');

const app = express();
const port = 8989;

// Bật CORS cho phép ứng dụng web kết nối từ localhost hoặc domain trường
app.use(cors({
  origin: '*',
  methods: ['GET', 'POST', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

app.use(express.json());

// Thư mục lưu trữ tạm thời cho các phiên ký
const tempDir = path.join(os.tmpdir(), "vgca_local_signs");
if (!fs.existsSync(tempDir)) {
    fs.mkdirSync(tempDir, { recursive: true });
}

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, tempDir);
    },
    filename: function (req, file, cb) {
        const safeName = file.originalname.replace(/[^a-zA-Z0-9.\-_]/g, '_');
        const finalName = Date.now() + '_' + safeName;
        cb(null, finalName);
    }
});

const upload = multer({ storage: storage });

/**
 * Hàm đọc danh sách chứng thư số có khóa bí mật (USB Token) từ Windows Certificate Store
 */
function getLocalCertificates() {
  const psScript = `
$OutputEncoding = [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$certs = Get-ChildItem "Cert:\\CurrentUser\\My" | Where-Object { $_.HasPrivateKey }
$list = @()
foreach ($c in $certs) {
    $sub = $c.Subject
    $iss = $c.Issuer
    if ($iss -like "*MS-Organization-Access*" -or $iss -like "*Microsoft*" -or $sub -match '^CN=[0-9a-fA-F-]{36}$') {
        continue
    }
    if ($sub -like "*trust_*") {
        continue
    }
    $isCa = ($iss -like "*Viettel*") -or ($iss -like "*VNPT*") -or ($iss -like "*Ban Cơ yếu*") -or ($iss -like "*VGCA*") -or ($iss -like "*BKAV*") -or ($iss -like "*FPT*") -or ($iss -like "*MISA*") -or ($iss -like "*SmartCA*") -or ($iss -like "*CA*")
    if ($isCa) {
        $cn = $sub
        if ($sub -match 'CN=([^,]+)') {
            $cn = $matches[1].Trim()
        }
        $issuerCn = $iss
        if ($iss -match 'CN=([^,]+)') {
            $issuerCn = $matches[1].Trim()
        }
        $list += [PSCustomObject]@{
            Subject = $cn
            FullSubject = $sub
            Issuer = $issuerCn
            FullIssuer = $iss
            SerialNumber = $c.SerialNumber
            ValidTo = $c.NotAfter.ToString("dd/MM/yyyy")
            NotAfter = $c.NotAfter.ToString("yyyy-MM-ddTHH:mm:ss")
        }
    }
}
$list | ConvertTo-Json -Compress
`;

  try {
    const encoded = Buffer.from(psScript, 'utf16le').toString('base64');
    const raw = execSync(`powershell -NoProfile -ExecutionPolicy Bypass -EncodedCommand ${encoded}`, {
      encoding: 'utf8',
      windowsHide: true,
      timeout: 10000
    });
    
    if (!raw || !raw.trim()) return [];
    const jsonIdx = raw.indexOf('[');
    if (jsonIdx === -1) {
      const singleObjIdx = raw.indexOf('{');
      if (singleObjIdx !== -1) {
        const parsed = JSON.parse(raw.substring(singleObjIdx).trim());
        return [parsed];
      }
      return [];
    }
    const parsed = JSON.parse(raw.substring(jsonIdx).trim());
    return Array.isArray(parsed) ? parsed : [parsed];
  } catch (err) {
    console.error('Error fetching certs:', err.message);
    return [];
  }
}

// 1. Kiểm tra trạng thái hoạt động của Local Service
app.get(['/', '/status'], (req, res) => {
    const vgcaPath = "C:\\Program Files (x86)\\VGCA\\VGCASignTool\\VGCASignTool.exe";
    res.json({
        online: true,
        service: "NSG VGCA Local Sign Bridge",
        version: "2.0.0",
        vgcaInstalled: fs.existsSync(vgcaPath),
        vgcaPath: vgcaPath
    });
});

// 2. Tự động đọc thông tin chứng thư số từ thiết bị USB Token đang cắm
app.get('/certificate', (req, res) => {
    try {
        const certs = getLocalCertificates();
        if (certs && certs.length > 0) {
            return res.json({
                success: true,
                message: `Đã tự động nhận diện ${certs.length} chứng thư số từ USB Token.`,
                certificate: certs[0],
                certificates: certs
            });
        } else {
            return res.json({
                success: false,
                message: "Không tìm thấy chứng thư số nào trong thiết bị USB Token đang cắm. Vui lòng kiểm tra lại thiết bị.",
                certificates: []
            });
        }
    } catch (err) {
        return res.status(500).json({
            success: false,
            message: "Lỗi khi đọc chứng thư số từ USB Token: " + err.message
        });
    }
});

// 3. Xử lý ký số: Mở VGCASignTool, đợi ký và tự động nhận lại file đã ký
app.post('/sign', upload.single('file'), (req, res) => {
    if (!req.file) {
        return res.status(400).json({ isSuccess: false, message: "Không tìm thấy file để ký." });
    }

    const vgcaToolPath = "C:\\Program Files (x86)\\VGCA\\VGCASignTool\\VGCASignTool.exe";
    if (!fs.existsSync(vgcaToolPath)) {
        return res.status(404).json({
            isSuccess: false,
            message: "Không tìm thấy phần mềm VGCASignTool tại: " + vgcaToolPath
        });
    }

    // Tạo thư mục làm việc riêng biệt cho phiên ký này
    const sessionId = `session_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const sessionDir = path.join(tempDir, sessionId);
    fs.mkdirSync(sessionDir, { recursive: true });

    const originalName = req.file.originalname || "document.pdf";
    const targetPdfPath = path.join(sessionDir, originalName);
    
    // Copy file tạm vào thư mục session với tên gốc
    fs.copyFileSync(req.file.path, targetPdfPath);
    try { fs.unlinkSync(req.file.path); } catch {}

    const initialStat = fs.statSync(targetPdfPath);
    const initialMtime = initialStat.mtimeMs;
    const initialSize = initialStat.size;

    console.log(`[${sessionId}] Đang mở VGCASignTool: "${vgcaToolPath}" "${targetPdfPath}"`);

    // Khởi chạy VGCASignTool với tham số file PDF
    const child = spawn(vgcaToolPath, [targetPdfPath], {
        detached: true,
        stdio: 'ignore'
    });
    child.unref();

    let isHandled = false;
    let pollTimer = null;
    const maxWaitMs = 10 * 60 * 1000; // Cho phép tối đa 10 phút để người dùng hoàn tất thao tác ký
    const startTime = Date.now();

    const cleanupSession = () => {
        if (pollTimer) clearInterval(pollTimer);
        setTimeout(() => {
            try {
                if (fs.existsSync(sessionDir)) {
                    fs.rmSync(sessionDir, { recursive: true, force: true });
                }
            } catch (err) {
                console.warn(`[${sessionId}] Lỗi dọn dẹp thư mục:`, err.message);
            }
        }, 20000); // Giữ lại 20s rồi dọn dẹp thư mục
    };

    const sendSignedFile = (signedPath) => {
        if (isHandled) return;
        isHandled = true;
        if (pollTimer) clearInterval(pollTimer);

        console.log(`[${sessionId}] Đã nhận diện văn bản ký số thành công: ${signedPath}`);
        res.download(signedPath, originalName, (err) => {
            if (err && !res.headersSent) {
                res.status(500).json({ isSuccess: false, message: "Lỗi khi truyền tải file đã ký", error: err.message });
            }
            cleanupSession();
        });
    };

    // Vòng lặp kiểm tra định kỳ 1 giây
    pollTimer = setInterval(() => {
        if (isHandled) return;

        // Quá thời gian chờ
        if (Date.now() - startTime > maxWaitMs) {
            isHandled = true;
            clearInterval(pollTimer);
            cleanupSession();
            return res.status(408).json({
                isSuccess: false,
                message: "Hết thời gian chờ ký số từ phần mềm VGCASignTool (10 phút)."
            });
        }

        try {
            if (!fs.existsSync(sessionDir)) return;
            const files = fs.readdirSync(sessionDir);

            // 1. Kiểm tra xem có file PDF mới nào được tạo trong sessionDir không (e.g. *_signed.pdf, *_DaKy.pdf...)
            const otherPdf = files.find(f => f.toLowerCase().endsWith('.pdf') && f !== originalName);
            if (otherPdf) {
                const otherPdfPath = path.join(sessionDir, otherPdf);
                const stat = fs.statSync(otherPdfPath);
                if (stat.size > 100) {
                    setTimeout(() => {
                        sendSignedFile(otherPdfPath);
                    }, 800);
                    return;
                }
            }

            // 2. Kiểm tra xem file gốc có bị ghi đè / thay đổi kích thước hoặc thời gian sửa đổi không
            if (fs.existsSync(targetPdfPath)) {
                const curStat = fs.statSync(targetPdfPath);
                if (curStat.mtimeMs > initialMtime + 800 || curStat.size !== initialSize) {
                    setTimeout(() => {
                        sendSignedFile(targetPdfPath);
                    }, 800);
                    return;
                }
            }
        } catch (checkErr) {
            console.warn(`[${sessionId}] Lỗi kiểm tra file:`, checkErr.message);
        }
    }, 1000);
});

app.listen(port, () => {
    console.log(`=======================================================`);
    console.log(`  NSG VGCA Local Sign Service v2.0 đang chạy tại:`);
    console.log(`  http://localhost:${port}`);
    console.log(`  - Cung cấp API nhận diện USB Token: /certificate`);
    console.log(`  - Cung cấp API ký số với VGCASignTool: /sign`);
    console.log(`=======================================================`);
});
