@echo off
title NSG VGCA Local Sign Service
chcp 65001 > nul
cd /d "%~dp0"

echo ========================================================
echo   HE THONG VAN PHONG SO - TRUONG CAO DANG BK NAM SAI GON
echo   Dich vu ket noi chu ky so USB Token & VGCASignTool
echo ========================================================
echo.
echo Dang khoi dong dich vu tai http://localhost:8989 ...
echo.

if exist "%~dp0node.exe" (
    "%~dp0node.exe" server.js
) else (
    node server.js
)

pause
