@echo off
title NSG VGCA Local Sign Service
chcp 65001 > nul
cd /d "%~dp0"

echo ========================================================
echo   HE THONG VAN PHONG SO - TRUONG CAO DANG BK NAM SAI GON
echo   Dich vu ket noi chu ky so USB Token & VGCASignTool
echo ========================================================
echo Dang khoi dong dich vu tai http://localhost:8989 ...

node server.js

pause
