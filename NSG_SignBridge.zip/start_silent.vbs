Set WshShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
currentDir = fso.GetParentFolderName(WScript.ScriptFullName)

WshShell.CurrentDirectory = currentDir

nodeExe = currentDir & "\node.exe"
If fso.FileExists(nodeExe) Then
    WshShell.Run """" & nodeExe & """ server.js", 0, False
Else
    WshShell.Run "node server.js", 0, False
End If
